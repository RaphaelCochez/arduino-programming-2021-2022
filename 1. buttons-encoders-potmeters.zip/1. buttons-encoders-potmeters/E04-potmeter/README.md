# Knipperende LED met potmeter
Onderdeel van Bas on Tech Nederlandstalige Arduino lessen - Zie https://arduino-lessen.nl

Abonneer je direct op het Bas on Tech YouTube kanaal via http://www.youtube.com/c/BasOnTechNL?sub_confirmation=1

## De schakeling
![alt text](./potmeter.png "schakel schema")

## Video
[![](http://img.youtube.com/vi/eTlsoSDBz7Y/0.jpg)](https://www.youtube.com/watch?v=eTlsoSDBz7Y "Knipperende LED met potmeter")