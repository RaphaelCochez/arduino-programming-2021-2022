## Fadende LED op breadboard
Onderdeel van Bas on Tech Nederlandstalige Arduino lessen - Zie https://arduino-lessen.nl

Abonneer je direct op het Bas on Tech YouTube kanaal via http://www.youtube.com/c/BasOnTechNL?sub_confirmation=1

## De schakeling
![alt text](./fade-led-pwm.png "schakel schema")

## Video
[![](http://img.youtube.com/vi/ii_Pn7fmZME/0.jpg)](https://www.youtube.com/watch?v=ii_Pn7fmZME "Fadende LED op breadboard")