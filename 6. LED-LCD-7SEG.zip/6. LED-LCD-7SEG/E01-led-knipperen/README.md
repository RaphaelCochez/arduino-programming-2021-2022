## Knipperende LED
Onderdeel van Bas on Tech Nederlandstalige Arduino lessen - Zie https://arduino-lessen.nl

Abonneer je direct op het Bas on Tech YouTube kanaal via http://www.youtube.com/c/BasOnTechNL?sub_confirmation=1

## Video
[![](http://img.youtube.com/vi/meo_OyqEbiM/0.jpg)](https://www.youtube.com/watch?v=meo_OyqEbiM "Knipperende LED")