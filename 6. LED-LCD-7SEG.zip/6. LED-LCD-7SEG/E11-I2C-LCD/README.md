# I2C LCD scherm met tekst en symbolen
Onderdeel van Bas on Tech Nederlandstalige Arduino lessen - Zie https://arduino-lessen.nl

Abonneer je direct op het Bas on Tech YouTube kanaal via http://www.youtube.com/c/BasOnTechNL?sub_confirmation=1

## Video
[![](http://img.youtube.com/vi/o9TrnCcZAGY/0.jpg)](http://www.youtube.com/watch?v=o9TrnCcZAGY "I2C LCD scherm met tekst en symbolen")

## De schakeling
![alt text](./i2c-lcd-ultrasoon.png "schakel schema")