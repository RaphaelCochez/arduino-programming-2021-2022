# Slide potentiometer
Part of the Bas on Tech Arduino YouTube tutorials - More info at https://arduino-tutorials.net

Subscribe to the Bas on Tech YouTube channel via http://www.youtube.com/c/BasOnTech?sub_confirmation=1

## The circuit
![alt text](./slide-potentiometer.png "the circuit")