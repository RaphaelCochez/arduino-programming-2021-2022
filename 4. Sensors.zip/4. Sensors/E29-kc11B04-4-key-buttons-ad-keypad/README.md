# Arduino 4 knops AD keypad
Onderdeel van Bas on Tech Nederlandstalige Arduino lessen - Zie https://arduino-lessen.nl

Abonneer je direct op het Bas on Tech YouTube kanaal via http://www.youtube.com/c/BasOnTechNL?sub_confirmation=1

## De schakeling
![alt text](./E29-kc11B04-4-key-buttons-ad-keypad.png "schakel schema")