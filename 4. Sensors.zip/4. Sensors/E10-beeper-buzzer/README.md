## Geluid uit een buzzer/beeper/piezo speaker
Onderdeel van Bas on Tech Nederlandstalige Arduino lessen - Zie https://arduino-lessen.nl

Abonneer je direct op het Bas on Tech YouTube kanaal via http://www.youtube.com/c/BasOnTechNL?sub_confirmation=1

## De schakeling
![alt text](./beeper-buzzer.png "schakel schema")

## Video
[![](http://img.youtube.com/vi/ouRahrmCu4k/0.jpg)](https://www.youtube.com/watch?v=ouRahrmCu4k "Geluid uit een buzzer/beeper/piezo speaker")