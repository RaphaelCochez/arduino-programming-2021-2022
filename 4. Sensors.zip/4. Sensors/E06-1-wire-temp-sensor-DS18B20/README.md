## 1-wire DS18B20 temperatuursensor uitlezen
Onderdeel van Bas on Tech Nederlandstalige Arduino lessen - Zie https://arduino-lessen.nl

Abonneer je direct op het Bas on Tech YouTube kanaal via http://www.youtube.com/c/BasOnTechNL?sub_confirmation=1

## De schakeling
![alt text](./1-wire-temp-sensor-DS18B20.png "schakel schema")

## Video
[![](http://img.youtube.com/vi/_kC0871xKks/0.jpg)](https://www.youtube.com/watch?v=_kC0871xKks "1-wire DS18B20 temperatuursensor uitlezen")