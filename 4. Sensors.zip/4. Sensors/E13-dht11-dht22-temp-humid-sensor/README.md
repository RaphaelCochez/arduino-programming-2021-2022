# DHT11 en DHT12 sensor
Onderdeel van Bas on Tech Nederlandstalige Arduino lessen - Zie https://arduino-lessen.nl

Abonneer je direct op het Bas on Tech YouTube kanaal via http://www.youtube.com/c/BasOnTechNL?sub_confirmation=1

## De schakeling
![alt text](./rotary-dht11-dht22.png "schakel schema")

## Video
[![](http://img.youtube.com/vi/2eKUI7Cq1nM/0.jpg)](https://www.youtube.com/watch?v=2eKUI7Cq1nM "DHT11")